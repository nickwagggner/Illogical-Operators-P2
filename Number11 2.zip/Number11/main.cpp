#include <iostream>

using namespace std;

int main(int argc, char *arv[])
{
	string cmd;

	cout<<"Would you like a directed graph (D) or an undirected graph (U)?"<<endl;
	cout<<">>>";
	cin>>cmd;

	if(cmd=="D")
	{
		int dMatrix [4][4];

		dMatrix[0][0] = 0;
		dMatrix[0][1] = 1;
		dMatrix[0][2] = 0;
		dMatrix[0][3] = 1;

		dMatrix[1][0] = 0;
		dMatrix[1][1] = 0;
		dMatrix[1][2] = 1;
		dMatrix[1][3] = 0;

		dMatrix[2][0] = 1;
		dMatrix[2][1] = 0;
		dMatrix[2][2] = 0;
		dMatrix[2][3] = 0;

		dMatrix[3][0] = 0;
		dMatrix[3][1] = 0;
		dMatrix[3][2] = 1;
		dMatrix[3][3] = 0;
		
		cout<<endl<<"  DIRECTED GRAPH"<<endl<<endl;
		cout<<"    A  B  C  D"<<endl;
		cout<<"   ------------"<<endl;

		for (int row=0; row<4; row++)
		{
			if(row==0)
				cout<<"A |";
			if(row==1)
				cout<<"B |";
			if(row==2)
				cout<<"C |";
			if(row==3)
				cout<<"D |";

			for (int col=0; col<4; col++)
			{
				cout<<" "<<dMatrix[row][col]<<" ";
			}

			cout<<"|"<<endl;
		}
		cout<<"   ------------"<<endl;

		string start;
		cout<<endl<<"Enter a vertex to start at: ";
		cin>>start;

		int hops;
		cout<<endl<<endl<<"Enter the number of hops allowed: ";
		cin>>hops;
	}

	else if(cmd=="U")
	{
		int unMatrix [4][4];

		unMatrix[0][0] = 0;
		unMatrix[0][1] = 1;
		unMatrix[0][2] = 1;
		unMatrix[0][3] = 1;

		unMatrix[1][0] = 1;
		unMatrix[1][1] = 0;
		unMatrix[1][2] = 1;
		unMatrix[1][3] = 0;

		unMatrix[2][0] = 1;
		unMatrix[2][1] = 1;
		unMatrix[2][2] = 0;
		unMatrix[2][3] = 0;

		unMatrix[3][0] = 1;
		unMatrix[3][1] = 0;
		unMatrix[3][2] = 0;
		unMatrix[3][3] = 0;
		
		cout<<endl<<"  UNDIRECTED GRAPH"<<endl<<endl;
		cout<<"    A  B  C  D"<<endl;
		cout<<"   ------------"<<endl;

		for (int row=0; row<4; row++)
		{
			if(row==0)
				cout<<"A |";
			if(row==1)
				cout<<"B |";
			if(row==2)
				cout<<"C |";
			if(row==3)
				cout<<"D |";

			for (int col=0; col<4; col++)
			{
				cout<<" "<<unMatrix[row][col]<<" ";
			}

			cout<<"|"<<endl;
		}
		cout<<"   ------------"<<endl;

		string start;
		cout<<endl<<"Enter a vertex to start at: ";
		cin>>start;

		int hops;
		cout<<endl<<endl<<"Enter the number of hops allowed: ";
		cin>>hops;
	}

	else
	{
		cout<<"Error: Invalid command"<<endl;
	}
	

	return 0;
}
