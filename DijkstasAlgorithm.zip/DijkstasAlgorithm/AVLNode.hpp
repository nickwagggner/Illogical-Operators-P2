/*
 * FILE: AVLNode.hpp
 * AUTHOR: Nick Wagner
 * DATE: 5/15/2021
 * PURPOSE: Declares the instance variables and methods for AVLNode.cpp
 */

#ifndef _AVL_NODE_HPP_
#define _AVL_NODE_HPP_

#include <iostream>

#include "Vertex.hpp"

class AVLNode
{
	private:
		//holds the vertex
		Vertex _vertex;
		
		//a pointer to the left child
		AVLNode *_left;
		
		//a pointer to the right child
		AVLNode *_right;
		
		//holds the height of the node
		int _height;

	public:
		//constructs a node when given an vertex
		AVLNode(Vertex ap): _vertex(ap), _left(nullptr), _right(nullptr), _height(1) {}
		
		//accessor and modifier for vertex
		Vertex veretx() const {return _vertex;}
		Vertex &vertex() {return _vertex;}
		
		//accessor and modifier for left child
		AVLNode* left() const {return _left;}
		AVLNode* &left() {return _left;}
		
		//accessor and modifier for right child
		AVLNode* right() const {return _right;}
		AVLNode* &right() {return _right;}
		
		//accessor and modifier for height
		int height() const {return _height;}
		int &height() {return _height;}
		
		//tells us if this node is a leaf node
		bool isLeaf() const {return !_left && !_right;}
		
		//inserts node into a specified sub tree
		AVLNode* insert(Vertex ap, AVLNode *intoSubTree);
		
		//looks up an vertex by name when given a name and sub tree
		Vertex lookUpByName(string vertexName, AVLNode *subTree);
		
		//removes a node when given an vertex and sub tree
		AVLNode* remove(Vertex ap, AVLNode *subTree);
		
		//returns the vertex in the tree with the smallest cost
		Vertex getSmallest(AVLNode *root);
		
		//updates the cost of an vertex in the name tree
		void updateCostNT(string name, int newCost, AVLNode *subTree);

		//updates the previous vertex in the name tree
		void updatePrevNT(string name, string newPrev, AVLNode *subTree);
};

#endif



