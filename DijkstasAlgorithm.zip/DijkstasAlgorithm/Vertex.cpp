/*
 * FILE: Vertex.cpp
 * AUTHOR: Nick Wagner
 * DATE: 11/15/2021
 * PURPOSE: Implements the methods found in Vertex.hpp
 */

#include "Vertex.hpp"
