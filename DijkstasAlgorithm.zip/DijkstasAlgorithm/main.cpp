/*
 * FILE: main.cpp
 * AUTHOR: Nick Wagner
 * DATE: 11/22/2021
 * PURPOSE: Dijkstra's Algorithm
 */

#include <iostream>
#include <fstream>
#include <list>

#include "Vertex.hpp"
#include "AVLTree.hpp"
#include "Edge.hpp"

using namespace std;

//uses Dijkstra's Algorithm to find the shortest path
void
Dijkstra(list<Edge> *table, AVLTree queue, AVLTree nameTree, string end, string start)
{
	string vertices[5] = {"A", "B", "C", "D", "E"};
	string verticesPrev[5] = {"X", "X", "X", "X", "X"};

	//while there are still vertices to visit
	while(queue.root())
	{
		//holds the vertex we are visiting
		Vertex smallest = queue.getSmallest();

		//holds the index of the vertex we are visting
		int tableIndex = smallest.index();

		//holds the current cost for the vertex we are visting
		int currCost = smallest.cost();

		//creates an iterator for the table
		list<Edge>::const_iterator tracker;

		//look at each of the edges from the vertex we are visiting
		for(tracker=table[tableIndex].begin(); tracker!=table[tableIndex].end(); tracker++)
		{
			//creates an iterator for the edges of the vertex
			Edge edge = *tracker;

			//look up the vertex in the nameTree to see if it has been visited
			Vertex lookUpResult = nameTree.lookUpByName(edge.dest());

			//if the vertex has not been visted yet...
			if(lookUpResult.name() == edge.dest())
			{
				//holds the shortest path we know to that vertex
				int knownCost = lookUpResult.cost();

				//holds a possible new path
				int alt = edge.cost() + currCost;

				//if this new path is the new shortest...
				if(alt < knownCost)
				{
					Vertex endingVertex = nameTree.lookUpByName(edge.dest());
					int endingIndex = endingVertex.index();

					//update the previous vertex for the current destination
					verticesPrev[endingIndex] = edge.start();

					//update the cost in the queue
					queue.remove(lookUpResult);
					lookUpResult.cost() = alt;
					queue.insert(lookUpResult);

					//update the cost in the nameTree 
					nameTree.updateCostNT(lookUpResult.name(), alt);
					
					//we have now visited the smallest
					nameTree.remove(smallest);
				}					
			}
		}


		//we can remove the smallest from the queue
		queue.remove(smallest);

		//if the shortest is the destination vertex, print the cost and path and exit the function
		if(smallest.name()==end)
		{
			//print the cost for the shortest path
			cout<<"Shortest Path Cost: "<<smallest.cost()<<endl;

			//holds the starting and ending vertices
			Vertex destVertex = nameTree.lookUpByName(end);
			Vertex startVertex = nameTree.lookUpByName(start);

			//holds the index that we eventually add to our path list
			int lookedAtIndex = destVertex.index();

			//creates a list that holds the best path
			list<string> *path = new list<string>;

			//while we have not added all the vertices in the path...
			while(lookedAtIndex!=startVertex.index())
			{
				//add this vertex to the path
				path->push_front(vertices[lookedAtIndex]);

				//set the vertex we look at to the pevious for the next loop iteration
				Vertex nextVertex = nameTree.lookUpByName(verticesPrev[lookedAtIndex]);
				lookedAtIndex = nextVertex.index();
			}

			//add the starting vertex to the begining of the path list
			path->push_front(start);

			//print out the path
			list<string>::const_iterator pathPrinter;
			for(pathPrinter=path->begin(); pathPrinter!=path->end(); pathPrinter++)
			{
				if(*pathPrinter!=path->front())
				{
					cout<<"->";
				}

				cout<<*pathPrinter;
			}

			cout<<endl<<endl;
		}
	}
}

int main(int argc, char *arv[])
{
	//there will be 5 airports
	int tableSize = 5;

	//creates the table
	list<Edge> *table = new list<Edge>[tableSize];

	//creates the tree that holds the vertices by name
	AVLTree nameTree;
	
	//creates the tree that holds the vertices by cost
	AVLTree queue;

	//create a vertices, give them an indices and insert them into both trees
	Vertex vA = Vertex("A", 0);
	nameTree.insert(vA);
	queue.insert(vA);

	Vertex vB = Vertex("B", 1);
	nameTree.insert(vB);
	queue.insert(vB);

	Vertex vC = Vertex("C", 2);
	nameTree.insert(vC);
	queue.insert(vC);

	Vertex vD = Vertex("D", 3);
	nameTree.insert(vD);
	queue.insert(vD);

	Vertex vE = Vertex("E", 4);
	nameTree.insert(vE);
	queue.insert(vE);

	//ADD EDGES TO EACH OF THE VERTICES IN THE TABLE

	//A to B (6)
	Edge AtoB = Edge("A", "B", 6);
	Edge BtoA = Edge("B", "A", 6);
	table[0].push_back(BtoA);
	table[1].push_back(AtoB);

	//A to D (1)
	Edge AtoD = Edge("A", "D", 1);
	Edge DtoA = Edge("D", "A", 1);
	table[0].push_back(AtoD);
	table[3].push_back(DtoA);

	//B to D (2)
	Edge BtoD = Edge("B", "D", 2);
	Edge DtoB = Edge("D", "B", 2);
	table[1].push_back(BtoD);
	table[3].push_back(DtoB);

	//B to E (2)
	Edge BtoE = Edge("B", "E", 2);
	Edge EtoB = Edge("E", "B", 2);
	table[1].push_back(BtoE);
	table[4].push_back(EtoB);

	//B to C (5)
	Edge BtoC = Edge("B", "C", 9);
	Edge CtoB = Edge("C", "B", 9);
	table[1].push_back(BtoC);
	table[2].push_back(CtoB);

	//C to E (5)
	Edge CtoE = Edge("C", "E", 5);
	Edge EtoC = Edge("E", "C", 5);
	table[2].push_back(CtoE);
	table[4].push_back(EtoC);

	//D to E (1)
	Edge DtoE = Edge("D", "E", 1);
	Edge EtoD = Edge("E", "D", 1);
	table[3].push_back(DtoE);
	table[4].push_back(EtoD);

	//show possible vertices to user
	cout<<endl<<"|--------------------------|"<<endl;
	cout<<"| Vertices = A, B, C, D, E |"<<endl;
	cout<<"|--------------------------|"<<endl<<endl;

	//prompt user to enter a starting vertex
	cout<<"Enter a starting vertex: ";
	string start;
	cin>>start;

	//update the cost of start in the nameTree
	nameTree.updateCostNT(start, 0);

	//look up starting vertex in the queue
	Vertex begin = queue.lookUpByName(start);

	//remove the starting vertex from the queue
	queue.remove(begin);

	//set the cost to 0 and insert the vertex back into the queue
	begin.cost() = 0;
	queue.insert(begin);

	//prompt user to enter a starting vertex
	cout<<"Enter a destination vertex: ";
	string destination;
	cin>>destination;
	cout<<endl;

	//call Dijkstra's Algorithm
	Dijkstra(table, queue, nameTree, destination, start);

	return 0;
}













