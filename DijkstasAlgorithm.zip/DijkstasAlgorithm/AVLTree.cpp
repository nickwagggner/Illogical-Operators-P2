/*
 * FILE: AVLTree.cpp
 * AUTHOR: Nick Wagner
 * DATE: 4/28/2021
 * PURPOSE: Implements the methods found in AVLTree.hpp
 */

#include "AVLTree.hpp"

#include <iostream>

//inserts an vertex into the tree
void
AVLTree::insert(Vertex ap)
{
	//if the tree is empty, the vertex inserted is now the root
	if(!_root)
	{
		_root = new AVLNode(ap);
	}
	
	//the tree is not empty so try inserting by starting at the root
	else
	{
		_root = _root->insert(ap, _root);
	}
}

//looks up an vertex when given a name
Vertex
AVLTree::lookUpByName(string vertexName)
{
	//holds the found vertex
	Vertex found;

	//if the root is the vertex we are looking for, return it
	if(_root->vertex().name() == vertexName)
	{
		found = _root->vertex();
	}
	
	//if not, look in the tree
	else
	{
		found = _root->lookUpByName(vertexName, _root);
	}
	
	return found;
}

//removes a given vertex
AVLNode*
AVLTree::remove(Vertex ap)
{
	//if there isnt a root, return an error message vertex
	if(!_root)
	{
		//I thought the naming here was funny lol
		Vertex errorPort = Vertex("The tree is empty", -1);
	
		AVLNode *error = new AVLNode(errorPort);
		return error;
	}
	
	//if there is a root, try to remove the vertex we are looking for
	else
	{
		return _root = _root->remove(ap, _root);
	}
}

//returns the vertex in the tree with the smallest cost
Vertex
AVLTree::getSmallest()
{
	return _root->getSmallest(_root);
}

//updates the cost of an vertex in the name tree
void
AVLTree::updateCostNT(string name, int newCost)
{
	//if the root is the vertex we are looking for, update the cost
	if(_root->vertex().name() == name)
	{
		_root->vertex().cost() = newCost;
		return;
	}
	
	//if not, look in the tree
	else
	{
		_root->updateCostNT(name, newCost, _root);
	}
}

//updates the previous vertex in the name tree
void
AVLTree::updatePrevNT(string name, string newPrev)
{
	//if the root is the vertex we are looking for, update the previous vertex
	if(_root->vertex().name() == name)
	{
		_root->vertex().prev() = newPrev;
		return;
	}
	
	//if not, look in the tree
	else
	{
		_root->updatePrevNT(name, newPrev, _root);
	}
}



