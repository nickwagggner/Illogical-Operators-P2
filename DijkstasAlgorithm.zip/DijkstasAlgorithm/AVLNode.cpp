/*
 * FILE: AVLNode.cpp
 * AUTHOR: Nick Wagner
 * DATE: 4/28/2021
 * PURPOSE: Implements the methods found in AVLNode.hpp
 */

#include "AVLNode.hpp"

#include <iostream>

using namespace std;

//returns the height of an AVLNode
int getHeight(AVLNode *node)
{
	//if the node is null, the height is zero
	if(!node)
	{
		return 0;
	}
	
	//since there is a node, return its height
	else
	{
		return node->height();
	}
}

//makes a single left rotation given the node that is causing the imbalance
AVLNode* rotateWithLeft(AVLNode *k2)
{
	//declares k1 as the left child of k2
	AVLNode *k1 = k2->left();
	
	//makes the left child of k2 equal to k1's right sub tree
	k2->left() = k1->right();
	
	//makes k2 the right child of k1
	k1->right() = k2;
	
	//update heights
	k2->height() = 1 + max(getHeight(k2->left()), getHeight(k2->right()));
	k1->height() = 1 + max(getHeight(k1->left()), getHeight(k2));
	
	//return the new root
	return k1;
}

//makes a single right rotation given the node that is causing the imbalance
AVLNode* rotateWithRight(AVLNode *k2)
{
	//declares k1 as the right child of k2
	AVLNode *k1 = k2->right();
	
	//makes the right child of k2 equal to k1's left sub tree
	k2->right() = k1->left();
	
	//makes k2 the left child of k1
	k1->left() = k2;
	
	//update heights
	k2->height() = 1 + max(getHeight(k2->left()), getHeight(k2->right()));
	k1->height() = 1 + max(getHeight(k1->left()), getHeight(k2));
	
	//return the new root
	return k1;
}

//makes a double roation on the left given the node that is causing the problem
AVLNode* doubleWithLeft(AVLNode *k3)
{
	//declares k1 as the left child of k3
	AVLNode *k1 = k3->left();
	
	//makes the left sub tree of k3 equal to k1's subtree rotated to the right once
	k3->left() = rotateWithRight(k1);
	
	//return the new root of the subtree after a left rotation
	return rotateWithLeft(k3);
}


//makes a double roation on the right given the node that is causing the problem
AVLNode* doubleWithRight(AVLNode *k3)
{
	//declares k1 as the right child of k3
	AVLNode *k1 = k3->right();
	
	//makes the right sub tree of k3 equal to k1's subtree rotated to the left once
	k3->right() = rotateWithLeft(k1);
	
	//return the new root of the subtree after a right rotation
	return rotateWithRight(k3);
}

//inserts a new node into a specified sub tree
AVLNode*
AVLNode::insert(Vertex ap, AVLNode *intoSubTree)
{
	//if I am the first node in the tree or I have found my place, insert and return the node
	if(intoSubTree==nullptr)
	{
		AVLNode *newRoot = new AVLNode(ap);
		return newRoot;
	}
	
	// if the nodes have the same cost, insert based on name
	else if(ap.cost() == intoSubTree->vertex().cost())
	{
		//if I am less than the sub tree being looked at
		if(ap.name() < intoSubTree->vertex().name())
		{
			//try inserting at left child
			intoSubTree->left() = insert(ap, intoSubTree->left());
			
			//update height
			int leftHeight = getHeight(intoSubTree->left());
			int rightHeight = getHeight(intoSubTree->right());
			
			//if there is an imbalance in the left sub tree
			if(leftHeight - rightHeight == 2)
			{
				//if this is a left-left imbalance
				if(ap.name() < intoSubTree->left()->vertex().name())
				{
					//make a single left rotation
					intoSubTree = rotateWithLeft(intoSubTree);
				}
				
				//this a left-right imbalance
				else
				{
					//make a double left rotation
					intoSubTree = doubleWithLeft(intoSubTree);
				}
			}
		}
		
		//if I am greater than the sub tree being looked at
		else if(ap.name() > intoSubTree->vertex().name())
		{
			//try inserting at right child
			intoSubTree->right() = insert(ap, intoSubTree->right());
			
			//update height
			int leftHeight = getHeight(intoSubTree->left());
			int rightHeight = getHeight(intoSubTree->right());
			
			//if there is an imbalance in the right sub tree
			if(rightHeight - leftHeight == 2)
			{
				//if this is a right-right imbalance
				if(ap.name() > intoSubTree->right()->vertex().name())
				{
					//make a single right rotation
					intoSubTree = rotateWithRight(intoSubTree);
				}
				
				//this a right-left imbalance
				else
				{
					//make a double right rotation
					intoSubTree = doubleWithRight(intoSubTree);
				}
			}
		}
	}
	
	//insert based on cost
	else
	{
		//if I am less than the sub tree being looked at
		if(ap.cost() < intoSubTree->vertex().cost())
		{
			//try inserting at left child
			intoSubTree->left() = insert(ap, intoSubTree->left());
			
			//update height
			int leftHeight = getHeight(intoSubTree->left());
			int rightHeight = getHeight(intoSubTree->right());
			
			//if there is an imbalance in the left sub tree
			if(leftHeight - rightHeight == 2)
			{
				//if this is a left-left imbalance
				if(ap.cost() < intoSubTree->left()->vertex().cost())
				{
					//make a single left rotation
					intoSubTree = rotateWithLeft(intoSubTree);
				}
				
				//this a left-right imbalance
				else
				{
					//make a double left rotation
					intoSubTree = doubleWithLeft(intoSubTree);
				}
			}
		}
		
		//if I am greater than the sub tree being looked at
		else if(ap.cost() > intoSubTree->vertex().cost())
		{
			//try inserting at right child
			intoSubTree->right() = insert(ap, intoSubTree->right());
			
			//update height
			int leftHeight = getHeight(intoSubTree->left());
			int rightHeight = getHeight(intoSubTree->right());
			
			//if there is an imbalance in the right sub tree
			if(rightHeight - leftHeight == 2)
			{
				//if this is a right-right imbalance
				if(ap.cost() > intoSubTree->right()->vertex().cost())
				{
					//make a single right rotation
					intoSubTree = rotateWithRight(intoSubTree);
				}
				
				//this a right-left imbalance
				else
				{
					//make a double right rotation
					intoSubTree = doubleWithRight(intoSubTree);
				}
			}
		}
	}
	
	//update the height of the sub tree
	intoSubTree->height() = 1 + max(getHeight(intoSubTree->left()), getHeight(intoSubTree->right()));
		
	return intoSubTree;	
}

//looks up an vertex by name when given a name and sub tree
Vertex
AVLNode::lookUpByName(string vertexName, AVLNode *subTree)
{
	//holds the vertex being looked for
	Vertex found;
	
	//if the vertex wasn't found, returna an empty vertex
	if(subTree == nullptr)
	{
		return found;
	}

	//if we have found the vertex, return it
	if(vertexName == subTree->vertex().name())
	{
		found = subTree->vertex();
		return found;
	}
	
	//if the name is greater than the name being looked at, look at their right child
	if(vertexName > subTree->vertex().name())
	{
		found = subTree->lookUpByName(vertexName, subTree->right());
	}
	
	//if the name is less than the name being looked at, look at their left child
	if(vertexName < subTree->vertex().name())
	{
		found = subTree->lookUpByName(vertexName, subTree->left());
	}
	
	return found;
}

//removes a node when given an vertex and sub tree
AVLNode*
AVLNode::remove(Vertex ap, AVLNode *subTree)
{	
	//if there is no subtree, return a nullptr
	if(!subTree)
	{
		return nullptr;
	}
	
	//if both nodes have the same cost, compare by name
	if(ap.cost() == subTree->vertex().cost())
	{
		// the vertex name being looked for is greater, look to the right sub tree
		if(ap.name() > subTree->vertex().name())
		{
			subTree->right() = remove(ap, subTree->right());
		}
		
		// the vertecx name being looked for is less, look to the left sub tree
		else if(ap.name() < subTree->vertex().name())
		{
			subTree->left() = remove(ap, subTree->left());
		}
		
		//we have found what we are looking for
		else
		{
			//if the node is just a leaf, rip it out
			if(subTree->isLeaf())
			{
				subTree = nullptr;
			}
			
			//if the node has two childern
			else if(subTree->left() && subTree->right())
			{
				//holds the node we will be deleting
				AVLNode *toDel = subTree->left();
				
				//find the greatest node in the left sub tree
				while(toDel->right())
				{
					toDel = toDel->right();
				}
				
				//hold the vertex of the node being deleted
				Vertex toMove = toDel->vertex();
				
				//remove the node that was to be deleted and give its vertex to subTree
				subTree->left() = remove(toMove, subTree->left());
				subTree->vertex() = toMove;
			}
			
			//the node has one child
			else
			{
				//if it is a left child, suck it up
				if(subTree->left())
				{
					subTree = subTree->left();
				}
				
				//if it is a right child, suck it up
				else
				{
					subTree = subTree->right();
				}
			}
		}
	}
	
	//compare by cost
	else
	{
		//if the cost of the vertex we are looking for is greater, look to the right
		if(ap.cost() > subTree->vertex().cost())
		{
			subTree->right() = remove(ap, subTree->right());
		}
		
		//if the cost of the vertex we are looking for is less, look to the left
		else if(ap.cost() < subTree->vertex().cost())
		{
			subTree->left() = remove(ap, subTree->left());
		}
		
		//we have found what we are looking for
		else
		{
			//if the node is a sub tree just rip it out		
			if(subTree->isLeaf())
			{
				subTree = nullptr;
			}
			
			//if the node has two childern
			else if(subTree->left() && subTree->right())
			{
				//holds the node we will be deleting
				AVLNode *toDel = subTree->left();
				
				//find the greatest node in the left sub tree
				while(toDel->right())
				{
					toDel = toDel->right();
				}
				
				//hold the vertex of the node being deleted
				Vertex toMove = toDel->vertex();
				
				//remove the node that was to be deleted and give its vertex to subTree
				subTree->left() = remove(toMove, subTree->left());
				subTree->vertex() = toMove;
			}
			
			//the node has a single child
			else
			{
				//if the child is on the left, suck it up
				if(subTree->left())
				{
					subTree = subTree->left();
				}
				
				//if the child is on the right, suck it up
				else
				{
					subTree = subTree->right();
				}
			}
		}
	}
	
	//if there is no sub tree, return nullptr
	if(!subTree)
	{
		return nullptr;
	}
	
	//calcualte the current balance
	int balance = getHeight(subTree->left()) - getHeight(subTree->right());
	
	//if the height of the left sub tree is 2 more than the right subtree
	if(balance==2)
	{
		//calculate balance of left sub tree
		int subBalance = getHeight(subTree->left()->left()) - getHeight(subTree->left()->right());
		
		//if this is a left left issue, do the proper rotations
		if(subBalance>0)
		{
			subTree = rotateWithLeft(subTree);
		}
		
		//if this is a left right issue, do the proper rotations
		else
		{
			subTree = doubleWithLeft(subTree);
		}
	}
	
	//if the height of the right sub tree is 2 more than the left subtree
	if(balance==-2)
	{
		//calculate balance of right sub tree
		int subBalance = getHeight(subTree->right()->left()) - getHeight(subTree->right()->right());
		
		//if this is a right right issue, do the proper rotations
		if(subBalance<0)
		{
			subTree = rotateWithRight(subTree);
		}
		
		//if this is a right left issue, do the proper rotations
		else
		{
			subTree = doubleWithRight(subTree);
		}
	}
	
	//update the height
	subTree->height() = 1 + max(getHeight(subTree->left()) , getHeight(subTree->right()));
	
	return subTree;
}


//returns the vertex in the tree with the smallest cost
Vertex
AVLNode::getSmallest(AVLNode *root)
{
	//holds the vertex we are looking for
	Vertex found;
	
	//if the root is the smallest element in the tree, return its vertex
	if(!root->left())
	{
		return root->vertex();
	}
	
	//the root has childern that are smaller
	else
	{
		//keep looking at the left child til there isnt one
		AVLNode *node = root->left();
				
		while(node->left())
		{
			node = node->left();
		}
		
		found = node->vertex();
	}
	
	return found;
}

//updates the cost of an vertex in the name tree
void
AVLNode::updateCostNT(string name, int newCost, AVLNode *subTree)
{
	//if we have found the vertex, update its cost
	if(subTree->vertex().name() == name)
	{
		subTree->vertex().cost() = newCost;
		return;
	}
	
	//if the name is greater than the one we are looking at, look at the right child
	else if(subTree->vertex().name() < name)
	{
		subTree->updateCostNT(name, newCost, subTree->right());
	}
	
	//if the name is less than the one we are looking at, look at the left child
	else if(subTree->vertex().name() > name)
	{
		subTree->updateCostNT(name, newCost, subTree->left());
	}
}

//updates the previous vertex in the name tree
void 
AVLNode::updatePrevNT(string name, string newPrev, AVLNode *subTree)
{
	//if we have found the vertex, update its previous
	if(subTree->vertex().name() == name)
	{
		subTree->vertex().prev() = newPrev;
		return;
	}
	
	//if the name is greater than the one we are looking at, look at the right child
	else if(subTree->vertex().name() < name)
	{
		subTree->updatePrevNT(name, newPrev, subTree->right());
	}
	
	//if the name is less than the one we are looking at, look at the left child
	else if(subTree->vertex().name() > name)
	{
		subTree->updatePrevNT(name, newPrev, subTree->left());
	}
}


