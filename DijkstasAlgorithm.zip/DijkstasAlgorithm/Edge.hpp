/*
 * FILE: Edge.hpp
 * AUTHOR: Nick Wagner
 * DATE: 4/28/2021
 * PURPOSE: Declares the instance variables and methods for Edge.cpp
 */

#ifndef _EDGE_HPP_
#define _EDGE_HPP_

#include <iostream>

using namespace std;

class Edge
{
	private:
		//holds the starting vertex
		string _start;

		//holds the destination vertex
		string _destination;
		
		//holds the cost for the edge
		int _cost;
	
	public:
		//constructs a edge given a destination and cost
		Edge(string start, string dest, int cost): _start(start), _destination(dest), _cost(cost) {}
		
		//accessor and modifier for destination
		string start() const {return _start;}
		string &start() {return _start;}

		//accessor and modifier for destination
		string dest() const {return _destination;}
		string &dest() {return _destination;}
		
		//accessor and modifier for cost
		int cost() const {return _cost;}
		int &cost() {return _cost;}
};

#endif
