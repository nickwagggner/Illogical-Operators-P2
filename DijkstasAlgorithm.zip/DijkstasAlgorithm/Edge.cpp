/*
 * FILE: Edge.cpp
 * AUTHOR: Nick Wagner
 * DATE: 4/28/2021
 * PURPOSE: Implements the methods found in Edge.hpp
 */

#include "Edge.hpp"
