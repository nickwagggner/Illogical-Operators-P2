/*
 * FILE: Vertex.hpp
 * AUTHOR: Nick Wagner
 * DATE: 11/16/2021
 * PURPOSE: Declares the instance variables and methods for Vertex.cpp
 */

#ifndef _VERTEX_HPP_
#define _VERTEX_HPP_

#include <iostream>
#include <climits>

using namespace std;

class Vertex
{
	private:
		//holds the name of the vertex
		string _name;
		
		//holds the index if the vertex
		int _index;
		
		//holds the cheapest cost to get to the vertex
		int _cost;

		//holds the name of the vertex visted to reach this one
		string _prev;
	
	public:
		//default constructor
		Vertex(): _name(""), _index(0), _cost(INT_MAX), _prev("X"){}
	
		//constructs an vertex when given a name and index
		Vertex(string name, int i): _name(name), _index(i), _cost(INT_MAX), _prev("X") {}
		
		//accessor and modifier for name
		string name() const {return _name;}
		string &name() {return _name;}
		
		//accessor and modifier for index
		int index() const {return _index;}
		int &index() {return _index;}
		
		//accessor and modifier for cost
		int cost() const {return _cost;}
		int &cost() {return _cost;}

		//accessor and modifier for prev
		string prev() const {return _prev;}
		string &prev() {return _prev;}
};

#endif
