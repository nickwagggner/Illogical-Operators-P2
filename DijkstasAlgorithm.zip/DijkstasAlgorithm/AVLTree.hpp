/*
 * FILE: AVLTree.hpp
 * AUTHOR: Nick Wagner
 * DATE: 4/28/2021
 * PURPOSE: Declares the instance variables and methods for AVLTree.cpp
 */

#ifndef _AVL_TREE_HPP_
#define _AVL_TREE_HPP_

#include "AVLNode.hpp"
#include "Vertex.hpp"

#include <iostream>

class AVLTree
{
	private:
		//points to the root of the tree
		AVLNode *_root;
		
	public:
		//default constructor for an empty tree
		AVLTree(): _root(nullptr) {}
		
		//accessor for root
		AVLNode* root() const {return _root;}
		
		//inserts an vertex into the tree
		void insert(Vertex ap);
		
		//looks up an vertex by name
		Vertex lookUpByName(string vertexName);
		
		//removes a specified vertex
		AVLNode* remove(Vertex ap);
		
		//returns the vertex in the tree with the smallest cost
		Vertex getSmallest();
		
		//updates the cost of an vertex in the name tree
		void updateCostNT(string name, int newCost);

		//updates the previous vertex in the name tree
		void updatePrevNT(string name, string newPrev);
};

#endif
